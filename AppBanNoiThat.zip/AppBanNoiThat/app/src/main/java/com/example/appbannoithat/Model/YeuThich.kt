package com.example.appbannoithat.Model

data class YeuThich(
    val nguoi_dung_id : String,
    val noi_that_id : String
)

data class TotalFav(
    val ID_noiThat : String,
    val total : String
)