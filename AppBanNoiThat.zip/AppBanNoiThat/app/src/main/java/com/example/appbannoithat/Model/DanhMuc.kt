package com.example.appbannoithat.Model

data class DanhMuc(
    val _id : String,
    val ten_danh_muc : String
)