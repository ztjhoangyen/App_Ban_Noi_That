package com.example.appbannoithat.Model

data class GioHang(
    val _id : String,
    val nguoi_dung_id : String,
    val trang_thai : Number,
    val tong_gia: Int,
    val tong_sl: Int
)