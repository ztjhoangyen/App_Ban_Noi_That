package com.example.appbannoithat.Model

data class LoaiNoiThat(
    val _id : String,
    val ten_loai : String,
    val img : String,
    val id_danh_muc : String
)