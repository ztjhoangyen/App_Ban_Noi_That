package com.example.bai.Constant

object AppInfo {
    const val APP_ID: Int = 2553
    const val MAC_KEY: String = "PcY4iZIKFCIdgZvA6ueMcMHHUbRLYjPL"
    const val URL_CREATE_ORDER: String = "https://sb-openapi.zalopay.vn/v2/create"
}