package com.example.appbannoithat.Model

data class Slideshow (
   val url: String
)