package com.example.appbannoithat.nav

enum class SortState {
    DEFAULT,
    NEWEST,
    PRICE_ASCENDING,
    PRICE_DESCENDING
}